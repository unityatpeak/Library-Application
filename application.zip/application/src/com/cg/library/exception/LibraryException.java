package com.cg.library.exception;

public class LibraryException extends Exception
{

	public LibraryException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
